/**
 //@FileName    :All_Init.h
 //@CreatedDate :2021��12��19��
 //@Author      :LiHao
 //@Description :
**/

#ifndef ALL_INIT_H_
#define ALL_INIT_H_

#include "zf_common_headfile.h"




void All_Init(void);
void send_image_init();


#endif /* ALL_INIT_H_ */
